import BeakerSVG from "./BeakerSVG.jsx";

export default function App() {
  return (
    <div className="page-shell">
      <div className="card">
        <h1>Beaker SVG Viewer</h1>
        <p>Interactive SVG animation rendered as a React component.</p>
        <BeakerSVG showObject displaced />
      </div>
    </div>
  );
}
